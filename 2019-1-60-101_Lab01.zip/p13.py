string = 'CSE303 is a course. CSE303 is very important course'
sub_string = 'CSE303'
count = 0
sub_len=len(sub_string)
for i in range(len(string)):
    if string[i:i+sub_len] == sub_string:
         count += 1
print(count)