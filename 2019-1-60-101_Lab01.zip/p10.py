my_list = [2, 4, 6, 9, 12, 1]
length=len(my_list)
my_list.sort()
print("Second largest element is:", my_list[length-2])