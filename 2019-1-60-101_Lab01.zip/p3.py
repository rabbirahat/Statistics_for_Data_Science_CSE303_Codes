# Write a Python program to calculate the compound interest based on the given formula. Read inputs
# from the user.
# A = P * (1 + R/100)T where P is the principle amount, R is the interest rate and T is time (in years).
# Define a function named as compound_interest_<your-student-id> in your program.

principle = float(input("Enter principle: "))
interest_rate = float(input("Enter interest_rate: "))
time = float(input("Enter time: "))
def compound_interest(P, R, T):
    A = P * (pow((1 + R / 100), T))
    CI = A - P
    print("Compound interest is: ", CI)
compound_interest(principle, interest_rate, time) # function call