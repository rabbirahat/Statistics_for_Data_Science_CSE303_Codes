n = int(input())
def prime_find(n):
    if n > 1:
        for x in range(2, int(n/2) + 1):
            if (n % x) == 0:
                print(n, "is not a prime number")
                break
        else:
            print(n, "is a prime number")
    else:
        print(n, "is neither prime nor composite ")
prime_find(n)