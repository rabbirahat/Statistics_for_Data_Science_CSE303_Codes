l1 = [2,5,7,4,11]
l2 = [25,26,24,12,9]
new_list = []
length1 = len(l1)
length2 = len(l2)
for i in range(0,length1):
    if( l1[i]%2!= 0):
        new_list.append(l1[i])

for i in range(0,length2):
    if( l2[i]%2 == 0):
        new_list.append(l2[i])
print(new_list)