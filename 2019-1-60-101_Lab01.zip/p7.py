my_list = [2, 3, 5, 5]
sum = 0
for x in range(0, len(my_list)):
	sum = sum + my_list[x]
print("Sum of all elements in the list: ", sum)
