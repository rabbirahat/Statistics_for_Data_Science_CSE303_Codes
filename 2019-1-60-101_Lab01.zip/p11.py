s = input("Enter any string: ")
for i in range(len(s)):
     if(i %2 ==0):
         print(s[i])