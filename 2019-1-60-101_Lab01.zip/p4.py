n = int(input("Enter any Positive Number  : "))
sum = 0
sum = (n * (n + 1) * (2 * n+ 1)) / 6
print(sum)