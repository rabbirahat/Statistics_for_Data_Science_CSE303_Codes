my_list = [2, 3, 5, 8, 2]
sum = 0
for x in range(0, len(my_list)):
    if x%2 == 0:
        sum = sum + my_list[x]
print("Sum of all even-indexed elements in the list: ", sum)