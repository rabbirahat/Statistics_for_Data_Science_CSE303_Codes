# Write a Python program to find the area and perimeter of a circle. Read inputs from the user.
r = float(input("Enter radius of a circle: "))

from math import  pi
print(format(pi * r * r, '.12g'))
print(format(2 * pi * r , '0.6f'))
