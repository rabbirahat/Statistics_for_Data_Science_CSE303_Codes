s=input("Enter any string: ")
length=len(s)
n=int(input("Enter a number: "))
newString=""
for i in range(0,length):
    if i>n:
        newString = newString+s[i]
print("New string is :",newString)