# Given two integer numbers, write a Python program to return their product.
# If the product is greater than 1000, then return their sum. Read inputs from the user.

num1 = int(input("Enter an integer: "))
num2 = int(input("Enter an integer: "))
product = num1 * num2
if product > 1000:
    print(num1+num2)
else:
    print(product)


