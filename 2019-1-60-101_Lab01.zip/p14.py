string=input("")
def palindrome_checker(string):
    rev = ''.join(reversed(string))
    if(string == rev):
        return True
    else:
        return False
result = palindrome_checker(string)
if(result):
    print("Palindrome")
else:
    print("Not palindrome")