my_list = [2, 4, 6, 9, 12]
def largest_number():
    largest = my_list[0]
    for x in range(1, len(my_list)):
        if (largest < my_list[x]):
            largest = my_list[x]
    print("The Largest Element in list : ", largest)

def smallest_number():
    smallest = my_list[0]
    for x in range(1, len(my_list)):
        if (smallest > my_list[x]):
            smallest = my_list[x]
    print("The Smallest Element in list : ", smallest)
smallest_number()
largest_number()