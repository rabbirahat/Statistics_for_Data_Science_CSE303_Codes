nums = [i for i in range (1,1001) if True in [True for divisor in range (2,10) if i % divisor == 0]]

print(nums)
