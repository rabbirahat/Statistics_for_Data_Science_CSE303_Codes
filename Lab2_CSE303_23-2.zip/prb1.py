num_list=[]
for x in range(1,1000):
    if x % 8 == 0:
        num_list.append(x)
print(num_list)

