def spaceCount(string):
    count = 0
    for i in range(0, len(string)):
        if string[i] == " ":
            count += 1
    return count
string = "Practice Problems to Drill List Comprehension in Your Head."
print("Number of spaces:", spaceCount(string))
