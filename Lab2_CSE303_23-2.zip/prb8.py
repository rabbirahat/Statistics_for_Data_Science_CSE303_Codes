nums = [i for i in range (1,1001)]

digit = {i: max ([divisor for divisor in range (1,10) if i % divisor == 0]) for i in nums}

print(digit)