nums = [i for i in range(0,1000) if '6' in str(i)]
print(nums)