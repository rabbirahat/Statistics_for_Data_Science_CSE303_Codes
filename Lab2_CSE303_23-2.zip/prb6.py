string = "Practice Problems to Drill List Comprehension in Your Head."
words = string.split (" ")
count = {i: len (i) for i in words}
print(count)
